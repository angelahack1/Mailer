# Mailer
A Mailer Lambda Function based on AWS API Gateway for AixKare WebSites.

## This is an application api for Amazon API Gateway, and is publicly available for my courses at Udemy in the near future.

You are free to study the code available in this site, it is aimed to help you in the implementation process of your own Website.

If you want to know more about some topic about this website, feel free to contact me at: angela.l.m@aixkare.com

Thanks to visit me seldom.

My Best Regards 
- Black Angy  ...(^_^)..*
